# HARDSTOREUY Service v0.1

Sistema web simple para control de reparaciones usando Google Apps Script + Google Sheets.

## Instalación rápida

1. Crea una hoja nueva en Google Sheets.
2. Ve a **Extensiones > Apps Script**.
3. Crea estos archivos en Apps Script y copia el contenido correspondiente:
   - `Code.gs`
   - `Database.gs`
   - `Utils.gs`
   - `Index.html`
   - `Logo.html`
   - `Styles.html`
   - `Dashboard.html`
   - `NuevaOrden.html`
   - `Ordenes.html`
   - `Script.html`
4. En **Configuración del proyecto**, activa que se muestre el archivo `appsscript.json` y reemplázalo por el incluido.
5. Ejecuta una vez la función `setupDatabase` y acepta los permisos.
6. Ve a **Implementar > Nueva implementación > Aplicación web**.
7. Ejecutar como: **Yo**. Acceso: según prefieras, por ejemplo **Cualquier usuario con el enlace**.
8. Abre el enlace desde las dos PC.

## Qué incluye

- Dashboard.
- Nueva orden.
- Listado y búsqueda.
- Edición de órdenes.
- Numeración automática HS-AÑO-000001.
- Link de WhatsApp listo para abrir conversación.

## Próximas mejoras sugeridas

- Envío real por WhatsApp Business API.
- Fotos del equipo.
- PDF/impresión personalizada.
- Historial visible.
- Caja y stock.
