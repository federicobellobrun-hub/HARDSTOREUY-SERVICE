const APP_NAME = 'HARDSTOREUY Service';
const SHEET_NAME = 'REPARACIONES';
const CONFIG_SHEET = 'CONFIG';

function doGet() {
  setupDatabase();
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle(APP_NAME)
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function apiInit() {
  setupDatabase();
  return {
    appName: APP_NAME,
    stats: getStats(),
    recent: listOrders('', 12),
    statuses: getStatuses(),
    types: getDeviceTypes()
  };
}
