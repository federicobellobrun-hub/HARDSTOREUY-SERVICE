const HEADERS = [
  'ID','Fecha','Cliente','Telefono','Tipo','Marca','Modelo','SerieIMEI','Problema','Accesorios',
  'Estado','Presupuesto','Tecnico','Observaciones','FechaFinalizacion','Historial','WhatsApp'
];

function getSS_() { return SpreadsheetApp.getActiveSpreadsheet(); }
function getSheet_() { setupDatabase(); return getSS_().getSheetByName(SHEET_NAME); }

function setupDatabase() {
  const ss = getSS_();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) sh.appendRow(HEADERS);
  const current = sh.getRange(1,1,1,Math.max(sh.getLastColumn(), HEADERS.length)).getValues()[0];
  HEADERS.forEach((h, i) => { if (current[i] !== h) sh.getRange(1, i+1).setValue(h); });
  sh.setFrozenRows(1);
  sh.getRange(1,1,1,HEADERS.length).setFontWeight('bold').setBackground('#f5f5f7');
  sh.autoResizeColumns(1, HEADERS.length);

  let cfg = ss.getSheetByName(CONFIG_SHEET);
  if (!cfg) {
    cfg = ss.insertSheet(CONFIG_SHEET);
    cfg.appendRow(['Clave','Valor']);
    cfg.appendRow(['ultimo_numero','0']);
    cfg.hideSheet();
  }
}

function nextOrderId_() {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = getSS_();
    const cfg = ss.getSheetByName(CONFIG_SHEET);
    const values = cfg.getDataRange().getValues();
    let row = values.findIndex(r => r[0] === 'ultimo_numero') + 1;
    if (row < 1) { cfg.appendRow(['ultimo_numero','0']); row = cfg.getLastRow(); }
    const last = Number(cfg.getRange(row,2).getValue() || 0) + 1;
    cfg.getRange(row,2).setValue(last);
    return 'HS-' + Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy') + '-' + String(last).padStart(6, '0');
  } finally { lock.releaseLock(); }
}

function mapRow_(row) {
  const obj = {};
  HEADERS.forEach((h,i) => obj[h] = row[i] || '');
  return obj;
}

function createOrder(data) {
  setupDatabase();
  const sh = getSheet_();
  const id = nextOrderId_();
  const now = new Date();
  const history = JSON.stringify([{fecha: now.toISOString(), accion: 'Orden creada', estado: 'Recibido'}]);
  const row = [
    id, now, clean_(data.Cliente), clean_(data.Telefono), clean_(data.Tipo), clean_(data.Marca), clean_(data.Modelo), clean_(data.SerieIMEI),
    clean_(data.Problema), clean_(data.Accesorios), data.Estado || 'Recibido', data.Presupuesto || '', clean_(data.Tecnico), clean_(data.Observaciones), '', history, ''
  ];
  sh.appendRow(row);
  return {ok:true, id:id, message:'Orden creada'};
}

function listOrders(query, limit) {
  setupDatabase();
  const sh = getSheet_();
  const last = sh.getLastRow();
  if (last < 2) return [];
  const rows = sh.getRange(2,1,last-1,HEADERS.length).getValues().map(mapRow_).reverse();
  const q = String(query || '').toLowerCase().trim();
  const filtered = q ? rows.filter(o => Object.values(o).join(' ').toLowerCase().includes(q)) : rows;
  return filtered.slice(0, limit || 100).map(formatOrder_);
}

function getOrder(id) {
  const sh = getSheet_();
  const data = sh.getDataRange().getValues();
  for (let i=1;i<data.length;i++) if (data[i][0] === id) return formatOrder_(mapRow_(data[i]));
  throw new Error('Orden no encontrada: ' + id);
}

function updateOrder(id, data) {
  const sh = getSheet_();
  const rows = sh.getDataRange().getValues();
  const idx = HEADERS.reduce((a,h,i)=>(a[h]=i,a),{});
  for (let r=1; r<rows.length; r++) {
    if (rows[r][0] === id) {
      const oldStatus = rows[r][idx.Estado];
      ['Cliente','Telefono','Tipo','Marca','Modelo','SerieIMEI','Problema','Accesorios','Estado','Presupuesto','Tecnico','Observaciones'].forEach(k => {
        if (data[k] !== undefined) sh.getRange(r+1, idx[k]+1).setValue(clean_(data[k]));
      });
      if (data.Estado && data.Estado !== oldStatus) {
        appendHistory_(sh, r+1, 'Cambio de estado', data.Estado);
        if (data.Estado === 'Listo para retirar' || data.Estado === 'Finalizado') sh.getRange(r+1, idx.FechaFinalizacion+1).setValue(new Date());
      }
      return {ok:true, message:'Orden actualizada'};
    }
  }
  throw new Error('Orden no encontrada');
}

function appendHistory_(sh, rowNumber, action, status) {
  const col = HEADERS.indexOf('Historial') + 1;
  let hist = [];
  try { hist = JSON.parse(sh.getRange(rowNumber, col).getValue() || '[]'); } catch(e) {}
  hist.push({fecha:new Date().toISOString(), accion:action, estado:status});
  sh.getRange(rowNumber, col).setValue(JSON.stringify(hist));
}

function getStats() {
  const orders = listOrders('', 10000);
  const count = s => orders.filter(o => o.Estado === s).length;
  return {
    total: orders.length,
    recibido: count('Recibido'),
    diagnostico: count('Diagnóstico'),
    reparando: count('Reparando'),
    esperando: count('Esperando repuesto'),
    listo: count('Listo para retirar'),
    entregado: count('Entregado')
  };
}

function formatOrder_(o) {
  if (o.Fecha instanceof Date) o.FechaTexto = Utilities.formatDate(o.Fecha, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm');
  else o.FechaTexto = String(o.Fecha || '');
  if (o.FechaFinalizacion instanceof Date) o.FechaFinalizacionTexto = Utilities.formatDate(o.FechaFinalizacion, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm');
  try { o.HistorialParsed = JSON.parse(o.Historial || '[]'); } catch(e) { o.HistorialParsed = []; }
  return o;
}

function clean_(v) { return String(v == null ? '' : v).trim(); }
