function getStatuses() {
  return ['Recibido','Diagnóstico','Esperando repuesto','Reparando','Listo para retirar','Entregado','No reparable'];
}

function getDeviceTypes() {
  return ['Celular','Computadora','Laptop','Impresora','Tablet','TV','Audio','Consola','Otro'];
}

function buildWhatsappLink(orderId) {
  const o = getOrder(orderId);
  const phone = String(o.Telefono || '').replace(/\D/g, '');
  const text = `Hola ${o.Cliente || ''}. Tu equipo ${o.Marca || ''} ${o.Modelo || ''} de la orden ${o.ID} ya está listo para retirar. HARDSTOREUY.`;
  return 'https://wa.me/' + phone + '?text=' + encodeURIComponent(text);
}
